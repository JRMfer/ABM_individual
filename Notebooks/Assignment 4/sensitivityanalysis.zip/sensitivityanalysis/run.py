from wolf_sheep.server import server

server.launch()
